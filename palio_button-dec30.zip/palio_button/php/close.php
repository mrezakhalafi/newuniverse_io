<?php 

    echo "<script>window.close();</script>";

?>