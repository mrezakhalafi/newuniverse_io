package com.example.paliolitesamplecode;

import android.os.Bundle;
import android.widget.Toast;

import io.newuniverse.PalioLibrary.Callback;
import io.newuniverse.PalioLibrary.PalioBaseActivity;

public class MainActivity extends PalioBaseActivity {

	@Override
	public void onCreate(Bundle bundle) {
		super.onCreate(bundle);

		setContentView(R.layout.activity_main);

		// Subscribe or contact us to get your Palio.io Account for your organization.
		// Please do not share your Palio.io Account or ever give it out to someone outside your organization.
		// Giving out your Palio.io Account may incur additional monthly charge.
		connect("REPLACE WITH YOUR PALIO ACCOUNT", this, new Callback() {

			@Override
			public void onSuccess(final String userId) {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						Toast.makeText(getBaseContext(), "Your Palio User ID is: " + userId, Toast.LENGTH_LONG).show();
					}
				});

				/**
				 The userId parameter in the onSuccess method will provide an identification of the Palio User ID
				 which is generated automatically and it can be mapped to the User ID on the application level.

				 So for example, Palio User ID (e.g. User001) can be mapped into your Application User ID (e.g. John Doe),
				 so you don't have to share the Application level User ID with Palio.io, but you can still monitor your user activities.

				 */
			}

			@Override
			public void onFailed(final String reason) {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (reason.equals("66")) {
							Toast.makeText(getBaseContext(), reason + ": Your Palio.io Account is invalid...", Toast.LENGTH_LONG).show();
						} else {
							Toast.makeText(getBaseContext(), reason + ": Something went wrong...", Toast.LENGTH_LONG).show();

						}
					}
				});
				// do something
			}
		});
	}
}
