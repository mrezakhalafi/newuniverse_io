package com.example.PalioLiteSampleCode;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;

import io.nexilis.nexilisbutton.Callback;
import io.nexilis.nexilisbutton.Nexilis;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);

        /*************************************
         Connect to our server with your newuniverse.io Account, and implement the required Callback.
         Please Subscribe or contact us to get your newuniverse.io Account.
         Do not share your newuniverse.io Account or ever give it out to someone outside your organization.
         ************************************/
        /**
         * Nexilis.connect (String NexilisAccount, Activity RegisteredActivity, int NexilisButtonMode, boolean UserMayModifyUID, Callback ConnectCallback)
         *
         * NexilisAccount 		: Your Nexilis.io Account.
         * RegisteredActivity 	: Android's Activity class that is used to register the Nexilis Button
         * NexilisButtonMode 	: The flag that determines when the Nexilis Button should appear.
         *      0 = Disabled Nexilis Button
         * 		1 = Within registered Activity, (Nexilis Button only appears when users are in the registered activity)
         * 		2 = Within App (Nexilis Button always appears as long as user is in the App),
         * 		3 = Always On (Nexilis Button always appears even if the application process is closed)
         * UserMayModifyUID 	: Sets whether users are allowed to change the Nexilis UserID.
         * 		true = enabled,
         * 		false = disabled
         * ConnectCallback	: The callback interface to be invoked when calling the method connect.
         * 		You need to implement onSuccess(String NexilisUserID) & onFailed(String reasonCode) to handle the RESULT.
         *
         */
        Nexilis.connect("***REPLACE***WITH***YOUR***NEXILIS***ACCOUNT***", this, 1, new Callback() {
            @Override
            public void onSuccess(final String NexilisUserID) {
                /**************************************
                 The NexilisUserID parameter is generated automatically and can be mapped to a User ID on the application level.
                 For example, the Nexilis User ID (e.g. User001) can be mapped into the corresponding Application User ID (e.g. John Doe),
                 so you don't have to share your Application User ID with Nexilis while still being able to monitor your user activities.
                 **************************************/
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getBaseContext(), "Your User ID: " + NexilisUserID, Toast.LENGTH_LONG).show();
                    }
                });
            }

            @Override
            public void onFailed(final String reasonCode) {
                /**
                 * reasonCode 	: Returns a code based on the status of the function connect called.
                 * 		2:Your trial subscription has expired. Please subscribe to continue using Nexilis.
                 * 		3:Your monthly subscription is not paid in full. Please pay your monthly subscription bill to continue using Nexilis service.
                 * 		4:Your Customer Engagement Credit has run out and your Prepaid Credit Balance is empty. Please top-up your Prepaid Credit Balance to continue using Nexilis
                 *		23:Unsupported Android version
                 * 		93:Missing the required overlay permission
                 * 		94:Unregistered User
                 * 		95:Invalid Nexilis Button Mode (1,2,3)
                 * 		96:Activity is null
                 * 		97:Account is empty
                 * 		98:Your account didn't match
                 * 		99:Something went wrong
                 */
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getBaseContext(), reasonCode, Toast.LENGTH_LONG).show();
                    }
                });
            }
        });

        /**
         *
         * An OPTIONAL Method to change your Nexilis User ID
         * You can call this method anytime after Nexilis.connect calls onSuccess
         *
         * String ResponCode = Nexilis.changeUsername(String NewUserID)
         *
         * ResponCode 	: Returns a code based on the status of the function call.
         * 		00:Success
         *		23:Unsupported Android version
         * 		94:Unregistered User
         * 		96:Activity is null
         * 		97:Account is empty
         * 		101:Unable to access server. Check your connection and try again later
         * 		102:Duplicate username
         * 		103:Username is empty
         * 		104:Username length is too short
         * 		105:Username length is too long
         * 		106:Illegal State. Be sure call Nexilis.connect and #callback state onSuccess called
         * NewUserID	: Desired User ID
         */
    }
}
