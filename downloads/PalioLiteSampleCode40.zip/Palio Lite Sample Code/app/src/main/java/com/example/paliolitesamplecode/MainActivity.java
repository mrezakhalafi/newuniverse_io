package com.example.paliolitesamplecode;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;

import io.newuniverse.paliobutton.Callback;
import io.newuniverse.paliobutton.Palio;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);

        /*************************************
         Connect to our server with your Palio.io Account, and implement the required Callback.
         Please Subscribe or contact us to get your Palio.io Account.
         Do not share your Palio.io Account or ever give it out to someone outside your organization.
         ************************************/
        /**
         * Palio.connect (String PalioAccount, Activity RegisteredActivity, int PalioButtonMode, boolean UserMayModifyUID, Callback ConnectCallback)
         *
         * PalioAccount         : Your Palio.io Account.
         * RegisteredActivity   : Android's Activity class that is used to register the Palio Button
         * PalioButtonMode      : The flag that determines when the Palio Button should appear.
         * 		1 = Within registered Activity, (Palio Button only appears when users are in the registered activity)
         * 		2 = Within App (Palio Button always appears as long as user is in the App),
         * 		3 = Always On (Palio Button always appears even if the application process is cloed)
         * UserMayModifyUID     : Sets whether users are allowed to change the Palio UserID.
         * 		true = enabled,
         * 		false = disabled
         * ConnectCallback      : The callback interface to be invoked when calling the method connect.
         * 		You need to implement onSuccess(String PalioUserID) & onFailed(String reasonCode) to handle the RESULT.
         *
         */
        Palio.connect("***REPLACE***WITH***YOUR***PALIO***ACCOUNT***", this, 1, true, new Callback() {

            @Override
            public void onSuccess(final String PalioUserID) {
                /**************************************
                 The userId parameter required by the onSuccess method, which is generated automatically, will act as
                 as a user's Palio User ID and it can be mapped to a User ID on the application level.
                 For example, the Palio User ID (e.g. User001) can be mapped into the corresponding Application User ID (e.g. John Doe),
                 so you don't have to share your Application User ID with Palio.io while still being able to monitor your user activities.
                 **************************************/
                /* do something */
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getBaseContext(), "Your Palio User ID: " + PalioUserID, Toast.LENGTH_LONG).show();
                    }
                });
            }

            @Override
            public void onFailed(final String reasonCode) {
                /**
                 * reasonCode 	: Returns a code based on the status of the function connect called.
                 * 		2:Your trial subscription has expired. Please subscribe to continue using Palio.io.
                 * 		3:Your monthly subscription is not paid in full. Please pay your monthly subscription bill to continue using Palio.io service.
                 * 		4:Your Customer Engagement Credit has run out and your Prepaid Credit Balance is empty. Please top-up your Prepaid Credit Balance to continue using Palio.io
                 * 		93:Missing the required overlay permission
                 * 		95:Invalid Palio Button Mode (1,2,3)
                 * 		96:Activity is null
                 * 		97:Account is empty
                 * 		98:Your account didn't match
                 * 		99:Something went wrong
                 */
                /* do something */
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getBaseContext(), reasonCode, Toast.LENGTH_LONG).show();
                    }
                });
            }
        });


        /**
         *
         * An OPTIONAL Method to change your Palio User ID
         * You can call this method anytime after Palio.connect calls onSuccess
         *
         * String ResponCode = Palio.changeUsername(String NewUserID)
         *
         * ResponCode 	: Returns a code based on the status of the function call.
         * 		00:Success
         * 		96:Activity is null
         * 		97:Account is empty
         * 		101:Unable to access server. Check your connection and try again later
         * 		102:Duplicate username
         * 		103:Username is empty
         * 		104:Username length is too short
         * 		105:Username length is too long
         * 		106:Illegal State. Be sure call Palio.connect and #callback state onSuccess called
         * NewUserID	: Desired User ID
         */
        String ResponCode = Palio.changeUsername("***REPLACE***WITH***NEW***USERID***");
    }
}
