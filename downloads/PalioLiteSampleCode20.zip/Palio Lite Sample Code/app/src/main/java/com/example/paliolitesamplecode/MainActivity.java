package com.example.paliolitesamplecode;

import android.os.Bundle;
import android.widget.Toast;

// Import Palio.io Libraries
import io.newuniverse.PalioLibrary.Callback;
import io.newuniverse.PalioLibrary.PalioBaseActivity;

// Extend the MainActivity with PalioBaseActivity
public class MainActivity extends PalioBaseActivity {

	@Override
	public void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		setContentView(R.layout.activity_main);

		/***********************************************************************************************************
		Connect to our server with your  Palio.io Account, and implement the required Callback.
		Please Subscribe or contact us to get your Palio.io Account.
		Do not share your Palio.io Account or ever give it out to someone outside your organization.
		************************************************************************************************************/
		connect("***REPLACE***WITH***YOUR***PALIO***ACCOUNT***", this, new Callback() {

			@Override
			public void onSuccess(final String userId) {
				/******************************************************************************************************************
				The userId parameter in the onSuccess method will provide an identification of the Palio User ID
				which is generated automatically and it can be mapped to the User ID on the application level.
				For example, Palio User ID (e.g. User001) can be mapped into your Application User ID (e.g. John Doe),
				so you don't have to share your Application User ID with Palio.io, but you can still monitor your user activities.
				******************************************************************************************************************/
				/*** do something ***/
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						Toast.makeText(getBaseContext(), "Your Palio User ID: " + userId, Toast.LENGTH_LONG).show();
					}
				});
			}

			@Override
			public void onFailed(final String reasonCode) {
				/*** do something ***/
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (reasonCode.equals("66")) {
							Toast.makeText(getBaseContext(), reasonCode + ": Invalid Palio.io Account. Please Subscribe or contact us to get your Palio.io Account", Toast.LENGTH_LONG).show();
						} else {
							Toast.makeText(getBaseContext(), reasonCode + ": Something went wrong...", Toast.LENGTH_LONG).show();
						}
					}
				});
			}
		});
	}
}
