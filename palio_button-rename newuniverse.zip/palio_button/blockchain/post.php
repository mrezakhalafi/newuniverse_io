<form action="chain.php" method="post">
<textarea name="json_data">
  {
    "from": "network",
    "to": "simone",
    "amount": 1
  }
</textarea>
<input type="submit">
</form>